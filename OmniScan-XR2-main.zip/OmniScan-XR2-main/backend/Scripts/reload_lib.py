import json

import os



def reload_spectral_config():

    lib_path = 'backend/Data/spectral_lib.json'

    if os.path.exists(lib_path):

        with open(lib_path, 'r') as f:

            new_config = json.load(f)

        print(f"📡 Cloud Core: Spectral Library Reloaded. Tracking {len(new_config['minerals'])} minerals.")

        return new_config

    return None



if __name__ == "__main__":

    reload_spectral_config()
